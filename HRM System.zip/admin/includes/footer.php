<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>@<a href="#">Md Tashhirul Islam</a></b>
    </div>
    <strong>Copyright &copy; 2019 HRM, Attendance and Payroll System </strong>
</footer>